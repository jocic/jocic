#!/bin/bash

# Initialization #

clear

if [ "$(id -u)" == "0" ];
then
	# Core Variables #

	SOURCE="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
	SOURCE_FILES=("/CryptoDock.jar" "/Uninstaller.sh" "/icons/ico/img_icon.ico" "/icons/ico/img_uninstall_icon.ico" "/icons/png/img_icon.png" "/icons/png/img_uninstall_icon.png" "/lib/commons-codec-1.6.jar")
	DEST_FOLDERS=("/usr/share/cryptodock" "/usr/share/cryptodock/icons" "/usr/share/cryptodock/icons/ico" "/usr/share/cryptodock/icons/png" "/usr/share/cryptodock/lib")
	DEST_FILES=("/usr/share/cryptodock/CryptoDock.jar" "/usr/share/cryptodock/Uninstaller.sh" "/usr/share/cryptodock/icons/ico/img_icon.ico" "/usr/share/cryptodock/icons/ico/img_uninstall_icon.ico" "/usr/share/cryptodock/icons/png/img_icon.png" "/usr/share/cryptodock/icons/png/img_uninstall_icon.png" "/usr/share/cryptodock/lib/commons-codec-1.6.jar")
	ICON_LOCATIONS=("$HOME/Desktop/CryptoDock.desktop" "/usr/share/applications/CryptoDock.desktop")

	# Welcome Message #

	echo -e "CryptoDock 1.0.2 Installation Script For Linux\n\nInstallation script was tested on:\n\n1. Ubuntu 14.04\n2. Linux Mint 17"

	# Directories #

	for (( i=0; i<${#DEST_FOLDERS[@]}; i++ ));
	do
		if [ ! -d "${DEST_FOLDERS[i]}" ]; then
			mkdir "${DEST_FOLDERS[i]}"
		fi
	done

	# Files #

	for (( i=0; i<${#DEST_FILES[@]}; i++ ));
	do
		if [ -f "${DEST_FILES[i]}" ];
		then
			echo
			while true; do
				read -p "- File '${DEST_FILES[i]}' exists, do you want to overwrite it? (y/n) - " yn;
				case $yn in
					[Yy]* ) cp "$SOURCE/Files${SOURCE_FILES[i]}" "${DEST_FILES[i]}"; chmod 644 "${DEST_FILES[i]}"; break;;
					[Nn]* ) break;;
					* ) echo -e "\n* Invalid answer. Answer with 'y' for yes or 'n' for no.\n";;
				esac
			done
		else
			cp "$SOURCE/Files${SOURCE_FILES[i]}" "${DEST_FILES[i]}"; chmod 644 "${DEST_FILES[i]}";
		fi
	done

	# Desktop Icon & Menu Icon #

	for (( i=0; i<${#ICON_LOCATIONS[@]}; i++ ));
	do
		echo "[Desktop Entry]" > "${ICON_LOCATIONS[i]}"
		echo "Encoding=UTF-8" >> "${ICON_LOCATIONS[i]}"
		echo "Name=CryptoDock" >> ${ICON_LOCATIONS[i]}
		echo "Comment=Encrypt or decrypt your sensitive data." >> "${ICON_LOCATIONS[i]}"
		echo "Exec=java -jar '/usr/share/cryptodock/CryptoDock.jar'" >> "${ICON_LOCATIONS[i]}"
		echo "Icon=/usr/share/cryptodock/icons/png/img_icon.png" >> "${ICON_LOCATIONS[i]}"
		echo "Terminal=false" >> "${ICON_LOCATIONS[i]}"
		echo "Type=Application" >> "${ICON_LOCATIONS[i]}"
		echo "Categories=Encryption;Encryption Tools;Utility;" >> "${ICON_LOCATIONS[i]}"
	done

	chmod 644 "/usr/share/applications/CryptoDock.desktop"
	chmod 777 "$HOME/Desktop/CryptoDock.desktop"

	# Installation Finish Message #

	echo -e "\nInstallation is finished, congratulations!\n\nImportant information:\n\n1. To run CryptoDock use the following command: java -jar '/usr/share/cryptodock/CryptoDock.jar'.\n2. To uninstall CryptoDock run the following script as root: '/usr/share/cryptodock/Uninstaller.sh'.\n\nIf you encounter any problems, report them to me over Twitter: @EnragedNibble"
else
	echo -e "* Error! CryptoDock 1.0.2 Installer must be run as root."
fi
