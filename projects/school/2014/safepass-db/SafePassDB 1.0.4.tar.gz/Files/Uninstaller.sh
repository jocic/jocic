#!/bin/bash

# Initialization #

clear

if [ "$(id -u)" == "0" ];
then
	# Core Variables #

	SOURCE="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
	ICON_LOCATIONS=("$HOME/Desktop/SafePassDB.desktop" "/usr/share/applications/SafePassDB.desktop")

	# Welcome Message #

	echo -e "SafePassDB 1.0.4 Uninstaller Script For Linux\n\nUninstaller was tested on:\n\n1. Ubuntu 14.04\n2. Linux Mint 17\n"

	# Confirmation #

	while true; do
		read -p "- Do you really want to uninstall SafePassDB 1.0.4 from your system? (y/n) - " yn;
		case $yn in
			[Yy]* ) rm -rf "/usr/share/safepassdb"; break;;
			[Nn]* ) exit;;
			* ) echo -e "\n* Invalid answer. Answer with 'y' for yes or 'n' for no.\n";;
		esac
	done

	# Delete Icons #

	for (( i=0; i<${#ICON_LOCATIONS[@]}; i++ ));
	do
		if [ ! -f "${DEST_FILES[i]}" ];
		then
			rm  "${ICON_LOCATIONS[i]}";
		fi
	done

	# Installation Finish Message #

	echo -e "\nSafePassDB 1.0.4 has been uninstalled from your system."
else
	echo -e "* Error! SafePassDB 1.0.4 Uninstaller must be run as root."
fi
